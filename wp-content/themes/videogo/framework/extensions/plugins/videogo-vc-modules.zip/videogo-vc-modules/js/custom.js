// JavaScript Document
jQuery( ".vc_col-sm-6" ).click(function() {  alert('Yes Pick');
  console.log( $( this ).text() );
});